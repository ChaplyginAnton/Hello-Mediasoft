
addmenu();
tableCreate();
addtext('Всем привет! Перед вами шахматы на JS');

var side = true;
var player_color='';
var opposite_player_color='';
var start = false;
var piece = '';
var move = 1;

core();
