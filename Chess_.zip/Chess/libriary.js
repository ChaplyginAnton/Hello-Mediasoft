//==============================================================================
// Функция очищает доску от всех фигур и опционально расставляет начальную расстановку (если start == 1)
//==============================================================================
function initial(start){
  var bod = document.body,
      table  = document.getElementsByTagName('table');                            // Получаем таблицу

      for(var i = 0; i < 10; i++){
        var tr = table[0].getElementsByTagName('tr');                            // Получаем строки
          for(var j = 0; j < 10; j++){
            var td = tr[i].getElementsByTagName('td');                           // Получаем ячейки
            if ((i == 1 || i == 2 || i == 7 || i == 8) && j != 0 && j != 9 && start) {                  // Вставляем фигуры - следующий этап:
              if (i == 1 && (j == 1 || j == 8)) { var str = String.fromCharCode(9820) }
              if (i == 1 && (j == 2 || j == 7)) { var str = String.fromCharCode(9822) }
              if (i == 1 && (j == 3 || j == 6)) { var str = String.fromCharCode(9821) }
              if (i == 1 && j == 4 ) { var str = String.fromCharCode(9819) }
              if (i == 1 && j == 5 ) { var str = String.fromCharCode(9818) }
              if (i == 2) { var str = String.fromCharCode(9823) }
              if (i == 7) { var str = String.fromCharCode(9817) }
              if (i == 8 && (j == 1 || j == 8)) { var str = String.fromCharCode(9814) }
              if (i == 8 && (j == 2 || j == 7)) { var str = String.fromCharCode(9816) }
              if (i == 8 && (j == 3 || j == 6)) { var str = String.fromCharCode(9815) }
              if (i == 8 && j == 4 ) { var str = String.fromCharCode(9813) }
              if (i == 8 && j == 5 ) { var str = String.fromCharCode(9812) }

            td[j].innerHTML = str;

           }
           if (i > 2 && i < 7 && j != 0 && j != 9 && start) {                    // Очищаем доску от фигур кроме стартовых
             td[j].innerHTML = '';
           }
           if (start == 0 && i != 9 && j != 9 && i != 0 && j != 0) {               // Очищаем доску от всех фигур
             td[j].innerHTML = '';
           }
        }
     }
}
//==============================================================================

//==============================================================================
// Функция пишет что за фигура по Char-коду символа
//==============================================================================
function figure (charcode) {
  if (charcode == String.fromCharCode(9820) || charcode == String.fromCharCode(9814)) {
    return 'R';
  }
  if (charcode == String.fromCharCode(9822) || charcode == String.fromCharCode(9816)) {
    return 'N';
  }
  if (charcode == String.fromCharCode(9821) || charcode == String.fromCharCode(9815)) {
    return 'B';
  }
  if (charcode == String.fromCharCode(9819) || charcode == String.fromCharCode(9813)) {
    return 'Q';
  }
  if (charcode == String.fromCharCode(9818) || charcode == String.fromCharCode(9812)) {
    return 'K';
  }
  if (charcode == String.fromCharCode(9823) || charcode == String.fromCharCode(9817)) {
    return '';
  }
  if (charcode == undefined || charcode == '') {
    return 'Free';
  }
}
//==============================================================================

//==============================================================================
// Функция определяет цвет фигуры по Char-коду символа
//==============================================================================
function color(charcode) {
  if (charcode == String.fromCharCode(9820) || charcode == String.fromCharCode(9822) || charcode == String.fromCharCode(9821) || charcode == String.fromCharCode(9819)|| charcode == String.fromCharCode(9818) || charcode == String.fromCharCode(9823)) {
    return 'Black';
  }

  if (charcode == String.fromCharCode(9817) || charcode == String.fromCharCode(9814) || charcode == String.fromCharCode(9816) || charcode == String.fromCharCode(9815) || charcode == String.fromCharCode(9813) || charcode == String.fromCharCode(9812)) {
    return 'White';
  }

  if (charcode == undefined || charcode == '') {
    return 'Free';
  }

}
//==============================================================================

//==============================================================================
// Функция определяет координаты в таблице по адресу
//==============================================================================
function getcoord(addr) {
  var ch = {};
  ch.x = addr.charCodeAt(0) - 64;
  ch.y = 9 - addr[1];
  return ch;
}
//==============================================================================

//==============================================================================
// Функция определяет адрес клетки по координатам
//==============================================================================
function getaddr(coord) {
  var addr = '';
  addr = String.fromCharCode(64 + +coord.x);
  addr += 9 - coord.y;
  return addr;
}
//==============================================================================

//==============================================================================
// Функция получает ссылку на ячейку таблицы по координатам
//==============================================================================
function getcell(addr) {
  var table  = document.getElementsByTagName('table');
  for(var i = 0; i < 10; i++){
    var tr = table[0].getElementsByTagName('tr');                            // Получаем строки
      for(var j = 0; j < 10; j++){
        var td = tr[i].getElementsByTagName('td');
        if (td[j].title == addr) {
          return td[j];
        }
      }
   }
}
//==============================================================================

//==============================================================================
// Функция ищет адрес короля 
//==============================================================================
function find_king(addr) {
  var table  = document.getElementsByTagName('table');
  for(var i = 0; i < 10; i++){
    var tr = table[0].getElementsByTagName('tr');                            // Получаем строки
      for(var j = 0; j < 10; j++){
        var td = tr[i].getElementsByTagName('td');
        if (td[j].title == addr) {
          return td[j];
        }
      }
   }
}
//==============================================================================



//==============================================================================
// Функция рисует подсказки с очередностью хода
//==============================================================================
function WhoIs(side) {
  if (side) {
     side_color = 'Белых';
     var left = 400;
     var top = 440;
  }
  if (!side) {
     side_color = 'Черных';
     var left = 400;
     var top = 30;
  }

  var tooltipElem = document.getElementsByTagName('div');
  if (tooltipElem[0]) {
    tooltipElem[0].remove();
    tooltipElem[0] = null;
  }
  tooltipElem = document.createElement('div');
  tooltipElem.className = 'tooltip';
  tooltipElem.innerHTML = 'Ход ' + side_color;
  document.body.append(tooltipElem);
  tooltipElem.style.left = left + 'px';
  tooltipElem.style.top = top + 'px';
}

function unselect(object,clas) {
  for (var i = 0; i < object.length; i++) {
    object[i].classList.remove(clas);
    i--;
  }
}
//==============================================================================

//==============================================================================
// Функция рисует всплывающие подсказки (пока не используется)
//==============================================================================
function tooltip() {
  let tooltipElem;
      document.onmouseover = function(event) {
        let target = event.target;
       // если у нас есть подсказка...
        let tooltipHtml = target.title;
        if (!tooltipHtml) return;
        // ...создадим элемент для подсказки
        tooltipElem = document.createElement('div');
        tooltipElem.className = 'tooltip';
        tooltipElem.innerHTML = 'Адрес поля - ' + tooltipHtml;
        document.body.append(tooltipElem);
        // спозиционируем его сверху от аннотируемого элемента (top-center)
        let coords = target.getBoundingClientRect();
        let left = coords.left + (target.offsetWidth - tooltipElem.offsetWidth) / 2;
        if (left < 0) left = 0; // не заезжать за левый край окна
        let top = coords.top - tooltipElem.offsetHeight - 5;
        if (top < 0) { // если подсказка не помещается сверху, то отображать её снизу
          top = coords.top + target.offsetHeight + 5;
        }
        tooltipElem.style.left = left + 'px';
        tooltipElem.style.top = top + 'px';
      };
      document.onmouseout = function(e) {
        if (tooltipElem) {
          tooltipElem.remove();
          tooltipElem = null;
        }
      };
}
//==============================================================================

//==============================================================================
// Функция движения пешки
//==============================================================================
function PawnMove(addr) {
  var fields = [];
  var candidate = {};
  var coord = getcoord(addr);
  var begin = getcell(addr);
  var ch_dop = false;
  if (color(begin.textContent) == 'White') {
     candidate.y = coord.y - 1;
     candidate.x = coord.x;
     var newaddres = getaddr(candidate);
     var newcell = getcell(newaddres);
     if (figure(newcell.textContent) == 'Free') {
      fields.push(newaddres);
      ch_dop = true;
     }
     candidate.y = coord.y - 2;
     candidate.x = coord.x;
     var newaddres = getaddr(candidate);
     var newcell = getcell(newaddres);
     if (figure(newcell.textContent) == 'Free' && coord.y == 7 && ch_dop) {
      fields.push(newaddres);
     }
     if (coord.x > 1) {
       candidate.y = coord.y - 1;
       candidate.x = coord.x - 1;
       var newaddres = getaddr(candidate);
       var newcell = getcell(newaddres);
       if (color(newcell.textContent) == 'Black') {
         fields.push(newaddres);
       }
     }
     if (coord.x < 8) {
       candidate.y = coord.y - 1;
       candidate.x = coord.x + 1;
       var newaddres = getaddr(candidate);
       var newcell = getcell(newaddres);
       if (color(newcell.textContent) == 'Black') {
         fields.push(newaddres);
       }
     }
  }

  if (color(begin.textContent) == 'Black') {
     candidate.y = coord.y + 1;
     candidate.x = coord.x;
     var newaddres = getaddr(candidate);
     var newcell = getcell(newaddres);
     if (figure(newcell.textContent) == 'Free') {
      fields.push(newaddres);
      ch_dop=true;
     }
     candidate.y = coord.y + 2;
     candidate.x = coord.x;
     var newaddres = getaddr(candidate);
     var newcell = getcell(newaddres);
     if (figure(newcell.textContent) == 'Free' && coord.y == 2 && ch_dop) {
      fields.push(newaddres);
     }
     if (coord.x > 1) {
       candidate.y = coord.y + 1;
       candidate.x = coord.x - 1;
       var newaddres = getaddr(candidate);
       var newcell = getcell(newaddres);
       if (color(newcell.textContent) == 'White') {
         fields.push(newaddres);
       }
     }
     if (coord.x < 8) {
       candidate.y = coord.y + 1;
       candidate.x = coord.x + 1;
       var newaddres = getaddr(candidate);
       var newcell = getcell(newaddres);
       if (color(newcell.textContent) == 'White') {
         fields.push(newaddres);
       }
     }
  }
  return fields;
}
//==============================================================================

//==============================================================================
// Функция движения ладьи
//==============================================================================
function RockMove(addr) {
  var fields = [];
  var candidate = {};
  var coord = getcoord(addr);
  var begin = getcell(addr);
  candidate.x = coord.x;
    for (var i = coord.y; i < 8; i++) {
      candidate.y = i + 1;
      var newaddres = getaddr(candidate);
      var newcell = getcell(newaddres);
      if (figure(newcell.textContent) == 'Free') {
       fields.push(newaddres);
      }
      if (figure(newcell.textContent) != 'Free' && color(newcell.textContent) != color(begin.textContent)) {
       fields.push(newaddres);
       break;
      }
      if (color(newcell.textContent) == color(begin.textContent)) break;
    }
    for (var i = coord.y; i > 1; i--) {
      candidate.y = i - 1;
      var newaddres = getaddr(candidate);
      var newcell = getcell(newaddres);
      if (figure(newcell.textContent) == 'Free') {
       fields.push(newaddres);
      }
      if (figure(newcell.textContent) != 'Free' && color(newcell.textContent) != color(begin.textContent)) {
       fields.push(newaddres);
       break;
      }
      if (color(newcell.textContent) == color(begin.textContent)) break;
    }

    candidate.y = coord.y;
      for (var i = coord.x; i < 8; i++) {
        candidate.x = i + 1;
        var newaddres = getaddr(candidate);
        var newcell = getcell(newaddres);
        if (figure(newcell.textContent) == 'Free') {
         fields.push(newaddres);
        }
        if (figure(newcell.textContent) != 'Free' && color(newcell.textContent) != color(begin.textContent)) {
         fields.push(newaddres);
         break;
        }
        if (color(newcell.textContent) == color(begin.textContent)) break;
      }
      for (var i = coord.x; i > 1; i--) {
        candidate.x = i - 1;
        var newaddres = getaddr(candidate);
        var newcell = getcell(newaddres);
        if (figure(newcell.textContent) == 'Free') {
         fields.push(newaddres);
        }
        if (figure(newcell.textContent) != 'Free' && color(newcell.textContent) != color(begin.textContent)) {
         fields.push(newaddres);
         break;
        }
        if (color(newcell.textContent) == color(begin.textContent)) break;
      }
  return fields;
}
//==============================================================================

//==============================================================================
// Функция движения коня
//==============================================================================
function KnightMove(addr) {
  var fields = [];
  var candidate = {};
  var coord = getcoord(addr);
  var begin = getcell(addr);
  candidate.y = coord.y + 2;
  candidate.x = coord.x + 1;
  if (candidate.y < 9 && candidate.x < 9 ) {
    var newaddres = getaddr(candidate);
    var newcell = getcell(newaddres);
    if (figure(newcell.textContent) == 'Free' || figure(newcell.textContent) != 'Free' && color(newcell.textContent) != color(begin.textContent)) {
     fields.push(newaddres);
    }
  }
  candidate.y = coord.y + 2;
  candidate.x = coord.x - 1;
  if (candidate.y < 9 && candidate.x > 0 ) {
    var newaddres = getaddr(candidate);
    var newcell = getcell(newaddres);
    if (figure(newcell.textContent) == 'Free' || figure(newcell.textContent) != 'Free' && color(newcell.textContent) != color(begin.textContent)) {
     fields.push(newaddres);
    }
  }
  candidate.y = coord.y + 1;
  candidate.x = coord.x + 2;
  if (candidate.y < 9 && candidate.x < 9 ) {
    var newaddres = getaddr(candidate);
    var newcell = getcell(newaddres);
    if (figure(newcell.textContent) == 'Free' || figure(newcell.textContent) != 'Free' && color(newcell.textContent) != color(begin.textContent)) {
     fields.push(newaddres);
    }
  }
  candidate.y = coord.y + 1;
  candidate.x = coord.x - 2;
  if (candidate.y < 9 && candidate.x > 0 ) {
    var newaddres = getaddr(candidate);
    var newcell = getcell(newaddres);
    if (figure(newcell.textContent) == 'Free' || figure(newcell.textContent) != 'Free' && color(newcell.textContent) != color(begin.textContent)) {
     fields.push(newaddres);
    }
  }
  candidate.y = coord.y - 2;
  candidate.x = coord.x + 1;
  if (candidate.y > 0 && candidate.x < 9 ) {
    var newaddres = getaddr(candidate);
    var newcell = getcell(newaddres);
    if (figure(newcell.textContent) == 'Free' || figure(newcell.textContent) != 'Free' && color(newcell.textContent) != color(begin.textContent)) {
     fields.push(newaddres);
    }
  }
  candidate.y = coord.y - 2;
  candidate.x = coord.x - 1;
  if (candidate.y > 0 && candidate.x > 0 ) {
    var newaddres = getaddr(candidate);
    var newcell = getcell(newaddres);
    if (figure(newcell.textContent) == 'Free' || figure(newcell.textContent) != 'Free' && color(newcell.textContent) != color(begin.textContent)) {
     fields.push(newaddres);
    }
  }
  candidate.y = coord.y - 1;
  candidate.x = coord.x + 2;
  if (candidate.y > 0 && candidate.x < 9 ) {
    var newaddres = getaddr(candidate);
    var newcell = getcell(newaddres);
    if (figure(newcell.textContent) == 'Free' || figure(newcell.textContent) != 'Free' && color(newcell.textContent) != color(begin.textContent)) {
     fields.push(newaddres);
    }
  }
  candidate.y = coord.y - 1;
  candidate.x = coord.x - 2;
  if (candidate.y > 0 && candidate.x > 0 ) {
    var newaddres = getaddr(candidate);
    var newcell = getcell(newaddres);
    if (figure(newcell.textContent) == 'Free' || figure(newcell.textContent) != 'Free' && color(newcell.textContent) != color(begin.textContent)) {
     fields.push(newaddres);
    }
  }
  return fields;
}
//==============================================================================

//==============================================================================
// Функция движения Слона
//==============================================================================
function BishopMove(addr) {
  var fields = [];
  var candidate = {};
  var coord = getcoord(addr);
  var begin = getcell(addr);
  candidate.x = coord.x + 1;
    for (var i = coord.y; i < 8; i++) {
      //alert(i + ' ' + coord.x);
      if (candidate.x > 8) break;
      candidate.y = i + 1;
      var newaddres = getaddr(candidate);
      var newcell = getcell(newaddres);
      if (figure(newcell.textContent) == 'Free') {
       fields.push(newaddres);
      }
      if (figure(newcell.textContent) != 'Free' && color(newcell.textContent) != color(begin.textContent)) {
       fields.push(newaddres);
       break;
      }
      if (color(newcell.textContent) == color(begin.textContent)) break;
      candidate.x++;
    }
    candidate.x = coord.x + 1;
    for (var i = coord.y; i > 1; i--) {
      if (candidate.x > 8) break;
      candidate.y = i - 1;
      var newaddres = getaddr(candidate);
      var newcell = getcell(newaddres);
      if (figure(newcell.textContent) == 'Free') {
       fields.push(newaddres);
      }
      if (figure(newcell.textContent) != 'Free' && color(newcell.textContent) != color(begin.textContent)) {
       fields.push(newaddres);
       break;
      }
      if (color(newcell.textContent) == color(begin.textContent)) break;
      candidate.x++;
    }
    candidate.x = coord.x - 1;
      for (var i = coord.y; i < 8; i++) {
       if (candidate.x < 1) break;
        candidate.y = i + 1;
        var newaddres = getaddr(candidate);
        var newcell = getcell(newaddres);
        if (figure(newcell.textContent) == 'Free') {
         fields.push(newaddres);
        }
        if (figure(newcell.textContent) != 'Free' && color(newcell.textContent) != color(begin.textContent)) {
         fields.push(newaddres);
         break;
        }
        if (color(newcell.textContent) == color(begin.textContent)) break;
        candidate.x--;
      }

    candidate.x = coord.x - 1;
      for (var i = coord.y; i > 1; i--) {
        if (candidate.x < 1) break;
        candidate.y = i - 1;
        var newaddres = getaddr(candidate);
        var newcell = getcell(newaddres);
        if (figure(newcell.textContent) == 'Free') {
         fields.push(newaddres);
        }
        if (figure(newcell.textContent) != 'Free' && color(newcell.textContent) != color(begin.textContent)) {
         fields.push(newaddres);
         break;
        }
        if (color(newcell.textContent) == color(begin.textContent)) break;
        candidate.x--;
      }
  return fields;
}
//==============================================================================

//==============================================================================
// Функция движения Короля
//==============================================================================
function KingMove(addr) {
  var fields = [];
  var candidate = {};
  var coord = getcoord(addr);
  var begin = getcell(addr);
  candidate.y = coord.y;
  candidate.x = coord.x + 1;
  if (candidate.x < 9) {
    var newaddres = getaddr(candidate);
    var newcell = getcell(newaddres);
    if (figure(newcell.textContent) == 'Free' || figure(newcell.textContent) != 'Free' && color(newcell.textContent) != color(begin.textContent)) {
      fields.push(newaddres);
    }
  }
  candidate.y = coord.y;
  candidate.x = coord.x - 1;
  if (candidate.x > 0) {
    var newaddres = getaddr(candidate);
    var newcell = getcell(newaddres);
    if (figure(newcell.textContent) == 'Free'|| figure(newcell.textContent) != 'Free' && color(newcell.textContent) != color(begin.textContent)) {
      fields.push(newaddres);
    }
  }
  candidate.y = coord.y + 1;
  candidate.x = coord.x;
  if (candidate.y < 9) {
    var newaddres = getaddr(candidate);
    var newcell = getcell(newaddres);
    if (figure(newcell.textContent) == 'Free'|| figure(newcell.textContent) != 'Free' && color(newcell.textContent) != color(begin.textContent)) {
      fields.push(newaddres);
    }
  }
  candidate.y = coord.y - 1;
  candidate.x = coord.x;
  if (candidate.y > 0) {
    var newaddres = getaddr(candidate);
    var newcell = getcell(newaddres);
    if (figure(newcell.textContent) == 'Free'|| figure(newcell.textContent) != 'Free' && color(newcell.textContent) != color(begin.textContent)) {
      fields.push(newaddres);
    }
  }
  candidate.y = coord.y + 1;
  candidate.x = coord.x + 1;
  if (candidate.y < 9 && candidate.x < 9 ) {
    var newaddres = getaddr(candidate);
    var newcell = getcell(newaddres);
    if (figure(newcell.textContent) == 'Free'|| figure(newcell.textContent) != 'Free' && color(newcell.textContent) != color(begin.textContent)) {
      fields.push(newaddres);
    }
  }
  candidate.y = coord.y + 1;
  candidate.x = coord.x - 1;
  if (candidate.y < 9 && candidate.x > 0 ) {
    var newaddres = getaddr(candidate);
    var newcell = getcell(newaddres);
    if (figure(newcell.textContent) == 'Free'|| figure(newcell.textContent) != 'Free' && color(newcell.textContent) != color(begin.textContent)) {
      fields.push(newaddres);
    }
  }
  candidate.y = coord.y - 1;
  candidate.x = coord.x + 1;
  if (candidate.y > 0 && candidate.x < 9 ) {
    var newaddres = getaddr(candidate);
    var newcell = getcell(newaddres);
    if (figure(newcell.textContent) == 'Free'|| figure(newcell.textContent) != 'Free' && color(newcell.textContent) != color(begin.textContent)) {
      fields.push(newaddres);
    }
  }
  candidate.y = coord.y - 1;
  candidate.x = coord.x - 1;
  if (candidate.y > 0 && candidate.x > 0 ) {
    var newaddres = getaddr(candidate);
    var newcell = getcell(newaddres);
    if (figure(newcell.textContent) == 'Free'|| figure(newcell.textContent) != 'Free' && color(newcell.textContent) != color(begin.textContent)) {
      fields.push(newaddres);
    }
  }
  return fields;
}
//==============================================================================
