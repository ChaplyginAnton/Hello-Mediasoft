//==============================================================================
// Функция очищает доску от всех фигур и опционально расставляет начальную расстановку (если start == 1)
//==============================================================================
function initial(start){
  var bod = document.body,
      table  = document.getElementsByTagName('table');                            // Получаем таблицу

      for(var i = 0; i < 10; i++){
        var tr = table[0].getElementsByTagName('tr');                            // Получаем строки
          for(var j = 0; j < 10; j++){
            var td = tr[i].getElementsByTagName('td');                           // Получаем ячейки
            if ((i == 1 || i == 2 || i == 7 || i == 8) && j != 0 && j != 9 && start) {                  // Вставляем фигуры - следующий этап:
              if (i == 1 && (j == 1 || j == 8)) { var str = String.fromCharCode(9820) }
              if (i == 1 && (j == 2 || j == 7)) { var str = String.fromCharCode(9822) }
              if (i == 1 && (j == 3 || j == 6)) { var str = String.fromCharCode(9821) }
              if (i == 1 && j == 4 ) { var str = String.fromCharCode(9819) }
              if (i == 1 && j == 5 ) { var str = String.fromCharCode(9818) }
              if (i == 2) { var str = String.fromCharCode(9823) }
              if (i == 7) { var str = String.fromCharCode(9817) }
              if (i == 8 && (j == 1 || j == 8)) { var str = String.fromCharCode(9814) }
              if (i == 8 && (j == 2 || j == 7)) { var str = String.fromCharCode(9816) }
              if (i == 8 && (j == 3 || j == 6)) { var str = String.fromCharCode(9815) }
              if (i == 8 && j == 4 ) { var str = String.fromCharCode(9813) }
              if (i == 8 && j == 5 ) { var str = String.fromCharCode(9812) }

            td[j].innerHTML = str;

           }
           if (i > 2 && i < 7 && j != 0 && j != 9 && start) {                    // Очищаем доску от фигур кроме стартовых
             td[j].innerHTML = '';
           }
           if (start == 0 && i != 9 && j != 9 && i != 0 && j != 0) {               // Очищаем доску от всех фигур
             td[j].innerHTML = '';
           }
        }
     }
}
//==============================================================================

//==============================================================================
// Функция пишет что за фигура по Char-коду символа
//==============================================================================
function figure (charcode) {
  if (charcode == String.fromCharCode(9820) || charcode == String.fromCharCode(9814)) {
    return 'R';
  }
  if (charcode == String.fromCharCode(9822) || charcode == String.fromCharCode(9816)) {
    return 'N';
  }
  if (charcode == String.fromCharCode(9821) || charcode == String.fromCharCode(9815)) {
    return 'B';
  }
  if (charcode == String.fromCharCode(9819) || charcode == String.fromCharCode(9813)) {
    return 'Q';
  }
  if (charcode == String.fromCharCode(9818) || charcode == String.fromCharCode(9812)) {
    return 'K';
  }
  if (charcode == String.fromCharCode(9823) || charcode == String.fromCharCode(9817)) {
    return '';
  }
  if (charcode == undefined || charcode == '') {
    return 'Free';
  }
}
//==============================================================================

//==============================================================================
// Функция определяет цвет фигуры по Char-коду символа
//==============================================================================
function color(charcode) {
  if (charcode == String.fromCharCode(9820) || charcode == String.fromCharCode(9822) || charcode == String.fromCharCode(9821) || charcode == String.fromCharCode(9819)|| charcode == String.fromCharCode(9818) || charcode == String.fromCharCode(9823)) {
    return 'Black';
  }

  if (charcode == String.fromCharCode(9817) || charcode == String.fromCharCode(9814) || charcode == String.fromCharCode(9816) || charcode == String.fromCharCode(9815) || charcode == String.fromCharCode(9813) || charcode == String.fromCharCode(9812)) {
    return 'White';
  }

  if (charcode == undefined || charcode == '') {
    return 'Free';
  }

}
//==============================================================================

//==============================================================================
function contains(arr, elem) {                                                      // Функция определяет есть ли в массиве указанный элемент
    for (let i = 0; i < arr.length; i++) {
        if (arr[i] === elem) {
            return true;
        }
    }
    return false;                                                                   // в случае не обнаружения элемента функция возвращает Ложь
}

//==============================================================================
// Функция определяет координаты в таблице по адресу
//==============================================================================
function getcoord(addr) {
  var ch = {};
  ch.x = addr.charCodeAt(0) - 64;
  ch.y = 9 - addr[1];
  return ch;
}
//==============================================================================

//==============================================================================
// Функция определяет адрес клетки по координатам
//==============================================================================
function getaddr(coord) {
  var addr = '';
  addr = String.fromCharCode(64 + +coord.x);
  addr += 9 - coord.y;
  return addr;
}
//==============================================================================

//==============================================================================
// Функция получает ссылку на ячейку таблицы по координатам
//==============================================================================
function getcell(addr) {
  var table  = document.getElementsByTagName('table');
  for(var i = 0; i < 10; i++){
    var tr = table[0].getElementsByTagName('tr');                            // Получаем строки
      for(var j = 0; j < 10; j++){
        var td = tr[i].getElementsByTagName('td');
        if (td[j].title == addr) {
          return td[j];
        }
      }
   }
}
//==============================================================================

//==============================================================================
// Функция ищет адрес королей
//==============================================================================
function find_king(side) {
  var table  = document.getElementsByTagName('table');
  var piece = getcell(addr);
  for(var i = 0; i < 10; i++){
    var tr = table[0].getElementsByTagName('tr');                            // Получаем строки
      for(var j = 0; j < 10; j++){
        var td = tr[i].getElementsByTagName('td');
        if (figure(td[j].textContent) == 'K' && color(td[j].textContent) == side) {
          return td[j].title;
        }
      }
   }
}
//==============================================================================

//==============================================================================
// Функция определяет есть ли угроза взятия поля
//==============================================================================
function Threat(addr, side) {
  var titles = [];
  var threats = [];
  var table  = document.getElementsByTagName('table');

  for(var i = 0; i < 10; i++){
    var tr = table[0].getElementsByTagName('tr');                            // Получаем строки
      for(var j = 0; j < 10; j++){
        var td = tr[i].getElementsByTagName('td');
        if (color(td[j].textContent) == side) {
          titles = titles.concat(td[j].title);
        }
      }
   }

   for (var i = 0; i < titles.length; i++) {
     begin = getcell(titles[i]);

     if (figure(begin.textContent) == '') {
       threats = threats.concat(PawnEat(titles[i]));
     }

     if (figure(begin.textContent) == 'R') {
       threats = threats.concat(RockMove(titles[i]));
     }

     if (figure(begin.textContent) == 'N') {
       threats = threats.concat(KnightMove(titles[i]));
     }

     if (figure(begin.textContent) == 'B') {
       threats = threats.concat(BishopMove(titles[i]));
     }

     if (figure(begin.textContent) == 'Q') {
       threats = threats.concat(RockMove(titles[i]));
       threats = threats.concat(BishopMove(titles[i]));
     }

     if (figure(begin.textContent) == 'K') {
       threats = threats.concat(KingMove(titles[i]));
     }

   }
   //alert(titles + threats);
  return contains(threats,addr);
}
//==============================================================================

//==============================================================================
// Функция определяет легальность хода
//==============================================================================

function legalmove(addr) {
  var fields = [];
  //var begin = table[0].querySelectorAll('td[title = \'addr\']');                // ? почему всегда undefined ?
  var begin = getcell(addr);

  if (figure(begin.textContent) == '') {
    fields = PawnMove(addr);
    fields = fields.concat(PawnEat(addr));
  }

  if (figure(begin.textContent) == 'R') {
    fields = RockMove(addr);
  }

  if (figure(begin.textContent) == 'N') {
    fields = KnightMove(addr);
  }

  if (figure(begin.textContent) == 'B') {
    fields = BishopMove(addr);
  }

  if (figure(begin.textContent) == 'Q') {
    fields = RockMove(addr);
    fields = fields.concat(BishopMove(addr));
  }

  if (figure(begin.textContent) == 'K') {
    fields = KingMove(addr);
    fields = fields.concat(KingCastle(addr));
  }

  for (var i = 0; i < fields.length; i++) {
    var newcell = getcell(fields[i]);
    newcell.classList.add('legal');
  }
     return fields;
}
