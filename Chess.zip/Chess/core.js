addmenu();
tableCreate();
addtext('Всем привет! Перед вами шахматы на JS');

var side = true;
var player_color='';
var opposite_player_color='';
var start = false;
var piece = '';
var move = 1;

core();
//==============================================================================
// Функция создания новой игры
//==============================================================================

function NewGame() {
  var textarea = document.getElementsByTagName('textarea');
  var lastone = document.getElementsByClassName('click');
  var lastselect = document.getElementsByClassName('legal');
  side = true;
  player_color='';
  opposite_player_color='';
  start = false;
  piece = '';
  move = 1;

  initial(1);
  WhoIs(true);
  textarea[0].value = '';
  unselect(lastselect,'legal');
  lastone[0].classList.remove('click')
}
//==============================================================================

//==============================================================================
// Функция основного движка игры
//==============================================================================
function core () {

  var table  = document.getElementsByTagName('table');
  var textarea = document.getElementsByTagName('textarea');
  var lastone = document.getElementsByClassName('click');
  var lastselect = document.getElementsByClassName('legal');

  initial(1);
  WhoIs(true);

  window.addEventListener('load', function(){
      table[0].addEventListener('click', function(e){

          let target = event.target;
          let tooltipHtml = target.title;
          if (!tooltipHtml) return;

          if (side) {
             player_color = 'White';
             opposite_player_color = 'Black';
          }
          if (!side) {
             player_color = 'Black';
             opposite_player_color = 'White';
          }

          if (start && color(target.textContent) == player_color) {
             lastone[0].classList.remove('click');
             target.classList.add('click');
             piece = target.textContent;
             start = true;
             unselect(lastselect,'legal');
             legalmove(target.title);
          }

          if (!start && color(target.textContent) == player_color) {
             target.classList.add('click');
             piece = target.textContent;
             start = true;
             unselect(lastselect,'legal');
             legalmove(target.title);
          }

          if (start && (figure(target.textContent) == 'Free' || color(target.textContent) == opposite_player_color)) {

             if (side) {
                textarea[0].value += move + '. '
             }

             if (figure(target.textContent) == 'Free' ) {
               textarea[0].value += figure(piece) + target.title + ' ';
             }

             if (color(target.textContent) == opposite_player_color ) {
               if (figure(piece) == '') {
                  textarea[0].value += lastone[0].title[0];
               }
               textarea[0].value += figure(piece) + 'x' + target.title + ' ';
             }

             if (!side) {
               textarea[0].value += '\n';
             }

             target.innerHTML = piece;
             lastone[0].innerHTML='';
             if (Threat(target.title,opposite_player_color)) {
               alert('Тебя тут могут сьесть!')
             }
             lastone[0].classList.remove('click');
             unselect(lastselect,'legal');
             start = false;
             side = !side;
             move += 0.5;
             WhoIs(side);
          }

      });
  });

}
//==============================================================================
